#!/bin/sh

GAMEDIR="$(dirname "$0" | sed 's/^\.\///' | sed 's/^\.$//')"
if [ "x$(echo "$0" | grep '^\/')" = "x" ] ; then
	if [ "x$GAMEDIR" = "x" ] ; then
		GAMEDIR="$PWD"
	else
		GAMEDIR="$PWD/$GAMEDIR"
	fi
fi

. $GAMEDIR/support.sh

LL=`stty -a | grep rows | sed 's/ rows; .*;//' | sed 's/.* //'` # ROWS
LC=`stty -a | grep col | sed 's/.*;.*; //' | sed 's/ .*//'` # COLUMNS

# Adjust these two values to suit.
MAX_CONCURRENCY=3
MAX_SECONDS=4
BASE_FRACTION=8   # 8 -> 1/8th of a second per frame by default

MAX_TICK=4000000000000000000
DO_MAIN="no"

rand()
{
	local RCH="$(dd if=/dev/urandom bs=1 count=1 2>/dev/null)"
	$GAMEDIR/ord "$RCH"
}

rand_with_range()
{
	# local MAX=$1

	# stamp "RWRTOP"

	# local RCH="$(dd if=/dev/urandom bs=4 count=1 2>/dev/null)"
	# local RAND="$($GAMEDIR/ord "$RCH")"
	# echo $(( $RAND % $MAX ))

	echo $(( $($GAMEDIR/ord `dd if=/dev/urandom bs=4 count=1 2>/dev/null`) % $1 ))

	# echo "RAND: " $(( $RAND % $MAX )) >> /tmp/fireworks_log
	# echo "scale=0; (((((($R1 * 256) + $R2) * 256) + $R3) * 256) + $R4) % $MAX" | bc
	# stamp "RWRBOTTOM"
}

stamp()
{
	# echo "$1: $($GAMEDIR/stamp)" >> /tmp/fireworks_log
	# if [ "x$NOSTAMP" != "x1" ] ; then
		# echo "$1: $($GAMEDIR/stamp)" 1>&2
	# fi
	return
}

do_loop()
{
	local TEST_MODE=$1
	local LOOP_MAX=$2

	# echo "TM: $TEST_MODE"

	stamp "TOP"

	if [ $TEST_MODE -eq 0 ] ; then
		DELAY="$(rand_with_range $MAX_DELAY_IN_TICKS)"
	elif [ $TEST_MODE -eq 1 ] ; then
		DELAY=$(( $LOOP_MAX + 10 ))
		BASE_DELAY=1
	elif [ $TEST_MODE -eq 2 ] ; then
		DELAY=1
		BASE_DELAY=1
	fi

	# echo "DELAY: $DELAY" >> /tmp/fireworks_log

	local TICK_COUNT=0
	local DO_DELAY2=0
	local DELAY2=0

	while true ; do
		stamp "LOOPTOP"
		$GAMEDIR/getch
		stamp "LOOPTOP2"

		DELAY=$(( $DELAY - 1 ))
		# echo "DELAY: $DELAY DO_DELAY2: $DO_DELAY2 DELAY2: $DELAY2" >> /tmp/fireworks_log
		if [ $DELAY -le 0 ] ; then
			# echo "PRE"
			stamp "PRELAUNCH"
			start_launch $TICK_COUNT $TEST_MODE
			if [ $TEST_MODE -eq 0 ] ; then
				DELAY="$(rand_with_range $MAX_DELAY_IN_TICKS)"
			else
				DELAY=$(( $LOOP_MAX + 10 ))
				SLOT_0_SIZE=11
			fi
			DO_DELAY2=1
			# echo "POST"
			stamp "POSTLAUNCH"
		fi
		TICK_COUNT=$((TICK_COUNT + 1))
		if [ $TICK_COUNT -gt $MAX_TICK ] ; then
			TICK_COUNT = 0;
		fi
		# echo "CURTIME $TICK_COUNT" >> /tmp/fireworks_log

		DELAY2=$(( $DELAY2 - 1 ))
		if [ $DO_DELAY2 -eq 1 ] ; then
			# echo "DELAY2: $DELAY2" >> /tmp/fireworks_log
			if [ $DELAY2 -le 0 ] ; then
				# echo "PRE2"
				# echo "IN DELAY2" >> /tmp/fireworks_log
				I=0
				stamp "PREUPDATELOOP"
				DO_DELAY2=0
				while [ $I -lt $MAX_CONCURRENCY ] ; do
					stamp "UPDATELOOP_1"
					if timetodraw $I $TICK_COUNT ; then
						stamp "UPDATELOOP_2"
						# echo "DEADLINE HIT FOR $I" >> /tmp/fireworks_log
						draw_slot $I $TICK_COUNT
						stamp "UPDATELOOP_3"
						TICK_COUNT=$(( $TICK_COUNT + $PENALTY_FOR_DRAW ))

						local SLOT_DEADLINE=$(eval echo "\$SLOT_$I"_DEADLINE)
						# echo "DEADLINE FOR $I: $SLOT_DEADLINE (CMP $TICK_COUNT)"
						if [ "x$SLOT_DEADLINE" != "x" ] ; then
							DO_DELAY2=1
							SLOT_OFFSET=$(($SLOT_DEADLINE - $TICK_COUNT))
							if [ $DELAY2 -lt $SLOT_OFFSET ] ; then
								DELAY2=$SLOT_OFFSET
							fi
						fi
						stamp "UPDATELOOP_4"
					fi
						stamp "UPDATELOOP_5"
					I=$(($I + 1))
				done
				stamp "POSTUPDATELOOP"
				# if [ $DO_DELAY2 -eq 0 ] ; then
					# echo "Nothing pending.  Disabling DELAY2"
				# fi
				# echo "POST2"
			fi
		fi
		if [ $TEST_MODE -ne 0 ] ; then
			if [ $TICK_COUNT -ge $LOOP_MAX ] ; then
				exit;
			fi
		fi
		stamp "LOOPEND"
	done

}

calibrate_timers()
{
	local PERIOD=100
	echo "Calibrating timers.  Please wait."

	while true ; do
		/usr/bin/time $GAMEDIR/fireworks.sh -T $PERIOD 2>/tmp/fireworks_timefile
		local LOOP_DURATION="$(cat /tmp/fireworks_timefile | sed -E 's/^[^0-9]*//' | sed 's/real.*$//' | sed 's/[^0-9.]//')"
		local INTDURATION="$(echo "$LOOP_DURATION" | sed 's/\..*$//')"
		if [ "x$INTDURATION" = "x" ] ; then
			INTDURATION=0;
		fi
		if [ "$INTDURATION" -ge 2 ] ; then
			break;
		fi
		PERIOD="$(($PERIOD * 4))"
		# echo "PERIOD NOW $PERIOD"
	done

	# echo "POINT A"

	/usr/bin/time $GAMEDIR/fireworks.sh -U $PERIOD 2>/tmp/fireworks_timefile
	local DRAW_DURATION="$(cat /tmp/fireworks_timefile | sed -E 's/^[^0-9]*//' | sed 's/real.*$//' | sed 's/[^0-9.]//')"

	# echo "POINT B"

	/usr/bin/time $GAMEDIR/fireworks.sh -V 2>/tmp/fireworks_timefile
	local LOAD_DURATION="$(cat /tmp/fireworks_timefile | sed -E 's/^[^0-9]*//' | sed 's/real.*$//' | sed 's/[^0-9.]//')"

	TICKS_PER_SECOND="$(echo "scale=20; $PERIOD/($LOOP_DURATION - $LOAD_DURATION)" | bc | sed 's/\..*$//')"

	# echo "POINT C"

	# echo "scale=20; (($DRAW_DURATION - $LOOP_DURATION - $LOAD_DURATION) * $TICKS_PER_SECOND) / 10"
	PENALTY_FOR_DRAW="$(echo "scale=20; (($DRAW_DURATION - $LOOP_DURATION - $LOAD_DURATION) * $TICKS_PER_SECOND) / 12" | bc | sed 's/\..*$//')"

	echo "Done calibrating.  TPS=$TICKS_PER_SECOND PFD: $PENALTY_FOR_DRAW"
	sleep 5
	clear
}

calibrate_timers_sub()
{
	local COUNT=$1

	local I=$COUNT
	while [ $I -gt 0 ] ; do
		$GAMEDIR/getch
		I="$(( $I - 1 ))"
	done
}

start_launch()
{
	local TIME=$1
	local TEST_MODE=$2

	# echo PRE 1>&2

	if [ $TEST_MODE != 0 ] ; then
		# echo "HERE"
		SLOT_1_X=20; SLOT_1_Y=12; SLOT_1_SIZE=0; SLOT_1_MAXSIZE=11;
		SLOT_1_DEADLINE=$(($TIME + 1)); SLOT_1_COLOR=4

	# eval "SLOT_$SLOT""_X=$X; SLOT_$SLOT""_Y=$Y; SLOT_$SLOT""_SIZE=0; SLOT_$SLOT""_MAXSIZE=$SIZE; SLOT_$SLOT""_DEADLINE=$TIME; SLOT_$SLOT""_COLOR=$COLOR"
		return;
	fi

	local TYPENUM=$(($(rand) % 3))

	if [ $TYPENUM = 0 ] ; then
		# CIRCLES
		local SIZE=13
		local ACTUAL_SIZE=16
	elif [ $TYPENUM = 1 ] ; then
		# STREAMER
		local SIZE=12
		local ACTUAL_SIZE=11
	else
		# BALL (0-11)
		local SIZE=$(rand_with_range 12)
		local ACTUAL_SIZE=$SIZE
	fi

	local COLOR=$(( $(rand_with_range 6) + 1))
	# echo COLOR: $COLOR >> /tmp/fireworks_log

	# local X=$(rand_with_range $(($LC - $ACTUAL_SIZE - 2)))
	# X=$(($X + ($ACTUAL_SIZE / 2) + 1))

	local X=$(( $(rand_with_range $(($LC - $ACTUAL_SIZE - 2))) + ($ACTUAL_SIZE / 2) + 1))

	# local Y=$(rand_with_range $(($LL - $ACTUAL_SIZE - 2)))
	# Y=$(($Y + ($ACTUAL_SIZE / 2) + 1))

	local Y=$(( $(rand_with_range $(($LL - $ACTUAL_SIZE - 2))) + ($ACTUAL_SIZE / 2) + 1))

	# $GAMEDIR/boom.sh -x "$X" "$Y" "$SIZE" "$COLOR" &

	# local SLOT=$(findfreeslot)
	local SLOT
	eval $FREESLOT_STRING
	if [ $SLOT -ge $MAX_CONCURRENCY ] ; then
		# echo "NO SLOTS AVAILABLE"
		return;
	fi

	eval "SLOT_$SLOT""_X=$X; SLOT_$SLOT""_Y=$Y; SLOT_$SLOT""_SIZE=0; SLOT_$SLOT""_MAXSIZE=$SIZE; SLOT_$SLOT""_DEADLINE=$TIME; SLOT_$SLOT""_COLOR=$COLOR"

	# echo "SLOT_1_X=$SLOT_1_X"
	# echo "SLOT_$SLOT""_X=$X; SLOT_$SLOT""_Y=$Y; SLOT_$SLOT""_SIZE=0; SLOT_$SLOT""_MAXSIZE=$SIZE; SLOT_$SLOT""_DEADLINE=$TIME; SLOT_$SLOT""_COLOR=$COLOR" ; exit

	# echo "START LAUNCH: \"$X\" \"$Y\" \"$SIZE\" \"$COLOR\" \"$SLOT\""
	# echo POST 1>&2
}

freeslotconfig()
{
	if [ "x$FREESLOT_CONFIGURED" = "x1" ] ; then
		echo "FREE SLOTS ALREADY CONFIGURED"
		return
	fi

	# echo "HERE"
	local i=0

	FREESLOT_STRING=""
	while [ $i -lt $MAX_CONCURRENCY ] ; do
		FREESLOT_STRING="$FREESLOT_STRING $EL""if [ x\$SLOT"_$i"_DEADLINE = x ] ; then SLOT=$i"
		EL="; el"
		i=$(($i+1))
	done
	FREESLOT_STRING="$FREESLOT_STRING ; else SLOT=$MAX_CONCURRENCY ; fi"

	FREESLOT_CONFIGURED=1

	# echo "TEST"
	eval $FREESLOT_STRING
	if [ "x$SLOT" != "x0" ] ; then
		echo "Free slot configuratoin failed."
	fi
	# echo "SLOT IS $SLOT"
	# echo "DONE"
}

findfreeslot()
{
	# echo "$FREESLOT_STRING" >> /tmp/fireworks_log

	eval $FREESLOT_STRING
	echo $SLOT
}

freeslot()
{
	local SLOT=$1
	eval "SLOT_$SLOT""_DEADLINE=\"\""
}

timetodraw()
{
	local SLOT=$1
	local CURTIME=$2

	local TIME=$(eval echo "\$SLOT_$SLOT"_DEADLINE)

	if [ "x$TIME" = "x" ] ; then
		# echo "SLOT $SLOT: NO TIME SET" >> /tmp/fireworks_log
		return -1
	fi

	# echo $CURTIME -lt $TIME
	if [ $CURTIME -lt $TIME ] ; then
		# echo "SLOT $SLOT: NOT TIME YET ($CURTIME -lt $TIME)" >> /tmp/fireworks_log
		return -1
	fi

	# echo "SLOT $SLOT: DEADLINE" >> /tmp/fireworks_log
	return 0
}

draw_slot()
{
	local SLOT=$1

	local X
	local Y
	local SIZE
	local REQMAXSIZE
	local TIME
	local COLOR

	eval "X=\$SLOT_$SLOT""_X; Y=\$SLOT_$SLOT""_Y; SIZE=\$SLOT_$SLOT""_SIZE ; REQMAXSIZE=\$SLOT_$SLOT""_MAXSIZE; TIME=\$SLOT_$SLOT""_DEADLINE; COLOR=\$SLOT_$SLOT""_COLOR"

	if [ $REQMAXSIZE -eq 13 ] ; then
		local MAXSIZE=16
		local TYPE="CIRCLES"
		local DELAY=$(($BASE_DELAY * 3))
	elif [ $REQMAXSIZE -eq 12 ] ; then
		local MAXSIZE=11
		local TYPE="STREAMER"
		local DELAY=$(($BASE_DELAY * 2))
	else
		local MAXSIZE=$REQMAXSIZE
		local TYPE="BALL"
		local DELAY=$(( ($BASE_DELAY * 3 ) / 2 ))
	fi

	# echo "\$$TYPE""_D$MAXSIZE""_MINBRIGHT" >> /tmp/fireworks_log
	local MINBRIGHT="$(eval echo "\$$TYPE""_D$MAXSIZE""_MINBRIGHT")"
	# vtsetpos 1 1

	# echo "SIZE: $MAXSIZE COLOR: $COLOR TYPE: $TYPE"

	hide_cursor
	boom2 "$X" "$Y" "$MAXSIZE" "$SIZE" "$COLOR" "$TYPE"
	# echo boom2 $X $Y $MAXSIZE $SIZE $COLOR $TYPE
	# echo boom2 $X $Y $MAXSIZE $SIZE $COLOR $TYPE >> /tmp/fireworks_log

	local TIME=$(( $TIME + $DELAY ))
	local SIZE=$(( $SIZE + 1 ))

	if [ $SIZE -gt $(( $MAXSIZE + 11 - $MINBRIGHT)) ] ; then
		freeslot $SLOT
		# echo "FREEING SLOT $SLOT" 1>&2
		# echo "FREEING SLOT $SLOT" >> /tmp/fireworks_log
	else
		eval "SLOT_$SLOT""_SIZE=$SIZE"
		# echo "SLOT_$SLOT""_DEADLINE=$TIME"
		eval "SLOT_$SLOT""_DEADLINE=$TIME"

		# echo "SLOT 0 TIME NOW $SLOT_0_DEADLINE" >> /tmp/fireworks_log
	fi

	# i=0
	# while [ $i -le $(( $MAXSIZE + 11 - $MINBRIGHT)) ] ; do
		# boom2 $X $Y $MAXSIZE $i $COLOR $TYPE
		# i=$(($i + 1))

		# k=0
		# while [ $k -le $DELAY ] ; do
			# CH="$($GAMEDIR/getch)"
			# k=$(($k + 1))
		# done
		# # sleep 1
	# done
	# # sleep 5
}

if [ "x$1" = "x-T" ] ; then
	# calibrate_timers_sub "$2"
	NOSTAMP=1
	do_loop 1 $2
	exit
fi

if [ "x$1" = "x-U" ] ; then
	. $GAMEDIR/boom.sh

	freeslotconfig
	NOSTAMP=1

	# calibrate_timers_sub "$2"
	PENALTY_FOR_DRAW=0
	do_loop 2 $2

	show_cursor
	exit
fi
if [ "x$1" = "x-V" ] ; then
	NOSTAMP=1
	. $GAMEDIR/boom.sh
	exit
fi

. $GAMEDIR/boom.sh

update_table_caches
freeslotconfig
calibrate_timers

MAX_DELAY_IN_TICKS="$(echo "scale=20; $TICKS_PER_SECOND * $MAX_SECONDS" | bc | sed 's/\..*$//')"
BASE_DELAY="$(echo "scale=20; $TICKS_PER_SECOND / $BASE_FRACTION" | bc | sed 's/\..*$//')"

# echo "TPS: $TICKS_PER_SECOND"

# echo "RWR[100]: $(rand_with_range 100)"
# echo "RWR[1000]: $(rand_with_range 1000)"
# echo "RWR[10000]: $(rand_with_range 10000)"
# echo "RWR[100000]: $(rand_with_range 100000)"

do_loop 0

