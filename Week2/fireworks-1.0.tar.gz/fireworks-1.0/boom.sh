#!/bin/sh

GAMEDIR="$(dirname "$0" | sed 's/^\.\///' | sed 's/^\.$//')"
if [ "x$(echo "$0" | grep '^\/')" = "x" ] ; then
	if [ "x$GAMEDIR" = "x" ] ; then
		GAMEDIR="$PWD"
	else
		GAMEDIR="$PWD/$GAMEDIR"
	fi
fi

. $GAMEDIR/tables.sh

if [ "x$BASE_DELAY" = "x" ] ; then
	BASE_DELAY=30
fi

# Show the cursor.  Call before exiting.
show_cursor()
{
    printf "%s" "$ESC[?25h"                           # show cursor
}

# Hide the cursor.  Call regularly.
hide_cursor()
{
    printf "%s" "$ESC[?25l"                           # hide cursor
}

# Resets the display and configures various settings.
vtreset()
{
    printf "%s" "$ESCc"                               # VT100 reset
    printf "%s" "$ESC[?71"                            # Turn off auto-wrap
    echo ; echo ""                            # clear screen
    hide_cursor
}

# Sets the cursor to a given row and column.
vtsetposstr()
{
    local VTS_ROW=$1
    local VTS_COL=$2

    # echo "ROW: '$VTS_ROW' COL: '$VTS_COL'"

    local VTS="$ESC[$VTS_ROW"";$VTS_COL""H"
    echo "$VTS"
}

vtsetpos()
{
    local VTS_ROW=$1
    local VTS_COL=$2

    # echo "ROW: '$VTS_ROW' COL: '$VTS_COL'"

    # printf "%s" "$ESC["
    # printf "%s" "$VTS_ROW"
    # printf "%s" ";"
    # printf "%s" "$VTS_COL"
    # printf "%s" "H"
    VTS="$(vtsetposstr $VTS_ROW $VTS_COL)"
    printf $VTS
    hide_cursor
}

# VT100 Commands

ESC=`printf "\e"`

# Set

# Options
SET="$ESC["
BOOLEAN="?"
SHOWHIDE=25
HIDDEN=l
VISIBLE=h

# Colors
FOREGROUND=3
BACKGROUND=4

BLACK=0
RED=1
GREEN=2
YELLOW=3
BLUE=4
MAGENTA=5
CYAN=6
WHITE=7
ORANGE=8 # Not a real color, but some special draw routines like in shelltris use it as a trick.
DEFAULT=9

# Attributes
INVERSE=7
UNDERLINE=4
BOLD=1

ENABLE=0
DISABLE=2

ATTRIBUTE="m"

boom()
{
		local X=$1
		local Y=$2
		local SIZE=$3
		local COLOR=$4

		# echo "X: $X Y: $Y MS: $SIZE C: $COLOR"
		# exit

		if [ $SIZE -eq 13 ] ; then
			local MAXSIZE=16
			local TYPE="CIRCLES"
			local DELAY=$(($BASE_DELAY * 3))
		elif [ $SIZE -eq 12 ] ; then
			local MAXSIZE=11
			local TYPE="STREAMER"
			local DELAY=$(($BASE_DELAY * 2))
		else
			local MAXSIZE=$SIZE
			local TYPE="BALL"
			local DELAY=$BASE_DELAY
		fi
		# echo "\$$TYPE""_D$MAXSIZE""_MINBRIGHT" >> /tmp/fireworks_log
		local MINBRIGHT="$(eval echo "\$$TYPE""_D$MAXSIZE""_MINBRIGHT")"
		# vtsetpos 1 1

		# echo "SIZE: $MAXSIZE COLOR: $COLOR TYPE: $TYPE"

		local i=0
		while [ $i -le $(( $MAXSIZE + 11 - $MINBRIGHT)) ] ; do
			boom1 $X $Y $MAXSIZE $i $COLOR $TYPE
			i=$(($i + 1))

			k=0
			while [ $k -le $DELAY ] ; do
				CH="$(./getch)"
				k=$(($k + 1))
			done
			# sleep 1
		done
		# sleep 5
}

boom1()
{
	local X=$1
	local Y=$2
	local MAX_EXPLOSION_DIAMETER=$3
	local SIZE=$4
	local COLOR=$5
	local TYPE=$6

	local BRIGHTNESS=10
	local MINBRIGHT="$(eval echo "\$$TYPE""_D$MAXSIZE""_MINBRIGHT")"

	# echo "X: $X Y: $Y MED: $MAX_EXPLOSION_DIAMETER S: $SIZE C: $COLOR T: $TYPE MINBRIGHT: $MINBRIGHT" 1>&2 ; return;

	if [ $SIZE -gt $(( $MAX_EXPLOSION_DIAMETER + (10 - $MINBRIGHT) )) ] ; then
		local BRIGHTNESS="C"
		local SIZE=$MAX_EXPLOSION_DIAMETER
	elif [ $SIZE -gt $MAX_EXPLOSION_DIAMETER ] ; then
		local BRIGHTNESS=$((10 - ($SIZE -$MAX_EXPLOSION_DIAMETER)))
		local SIZE=$MAX_EXPLOSION_DIAMETER
	fi

	local HCENTER="$(eval echo "\$$TYPE""_D$SIZE""_HCENTER")"
	local VCENTER="$(eval echo "\$$TYPE""_D$SIZE""_VCENTER")"
	local NLINES="$(eval "echo \"\$$TYPE""_D$SIZE""_NLINES\"")"

	# echo "NLINES: $NLINES"
	# echo "BD10: $BALL_D10_NLINES"

	local HPOS=$(($X - HCENTER + 1))
	local VPOS=$(($Y - VCENTER + 1))

	local i=1;

	# echo "I: \"$i\" NLINES: \"$NLINES\" ED: \"$MAX_EXPLOSION_DIAMETER\"";
	# echo "SIZE: $SIZE BRIGHTNESS: $BRIGHTNESS" >> /tmp/fireworks_log

	local START="$SET$FOREGROUND$COLOR$ATTRIBUTE"
	local END="$SET$FOREGROUND$DEFAULT$ATTRIBUTE"

	STRING="echo \""
	while [ $i -le $NLINES ] ; do
		local POS="\$(vtsetposstr \$(($VPOS + $i)) $HPOS)"
		local LINE="\$$TYPE""_D$SIZE""_B$BRIGHTNESS""_LINE$i"
		# echo "LINE"
		# vtsetpos $(($VPOS + $i)) $HPOS
		STRING="$STRING$POS$START$LINE$END"
		i=$(($i + 1))
	done
	STRING="$STRING\""
	eval "$STRING"
	# echo $STRING > /tmp/fireworks_string

	# while [ $i -le $NLINES ] ; do
		# local POS="$(vtsetposstr $(($VPOS + $i)) $HPOS)"
		# local LINE="$(eval echo "\"\$$TYPE""_D$SIZE""_B$BRIGHTNESS""_LINE$i\"")"
		# # echo "LINE"
		# # vtsetpos $(($VPOS + $i)) $HPOS
		# printf "%s" "$POS$START$LINE$END"
		# i=$(($i + 1))
	# done

}

boom2()
{
	local X=$1
	local Y=$2
	local MAX_EXPLOSION_DIAMETER=$3
	local SIZE=$4
	local COLOR=$5
	local TYPE=$6

	local BRIGHTNESS=10
	local MINBRIGHT="$(eval echo "\$$TYPE""_D$MAXSIZE""_MINBRIGHT")"

	# echo "X: $X Y: $Y MED: $MAX_EXPLOSION_DIAMETER S: $SIZE C: $COLOR T: $TYPE MINBRIGHT: $MINBRIGHT" 1>&2 ; return;

	if [ $SIZE -gt $(( $MAX_EXPLOSION_DIAMETER + (10 - $MINBRIGHT) )) ] ; then
		local BRIGHTNESS="C"
		local SIZE=$MAX_EXPLOSION_DIAMETER
	elif [ $SIZE -gt $MAX_EXPLOSION_DIAMETER ] ; then
		local BRIGHTNESS=$((10 - ($SIZE -$MAX_EXPLOSION_DIAMETER)))
		local SIZE=$MAX_EXPLOSION_DIAMETER
	fi

	local HCENTER="$(eval echo "\$$TYPE""_D$SIZE""_HCENTER")"
	local VCENTER="$(eval echo "\$$TYPE""_D$SIZE""_VCENTER")"
	local NLINES="$(eval "echo \"\$$TYPE""_D$SIZE""_NLINES\"")"

	# echo "NLINES: $NLINES"
	# echo "BD10: $BALL_D10_NLINES"

	local HPOS=$(($X - HCENTER + 1))
	local VPOS=$(($Y - VCENTER + 1))

	local i=1;

	# echo "I: \"$i\" NLINES: \"$NLINES\" ED: \"$MAX_EXPLOSION_DIAMETER\"";
	# echo "SIZE: $SIZE BRIGHTNESS: $BRIGHTNESS" >> /tmp/fireworks_log

	local START="$SET$FOREGROUND$COLOR$ATTRIBUTE"
	local END="$SET$FOREGROUND$DEFAULT$ATTRIBUTE"

	local STRING="echo \"\$""$TYPE""_D""$SIZE""_B""$BRIGHTNESS""_CACHEDATA\" | sed -e 's/\$VTS_ROW/'$VPOS'/g' -e 's/\$VTS_COL/'$HPOS'/g' -e 's/\$COLOR/'$COLOR'/g'"
	# echo "$STRING"
	eval "$STRING"

}


if [ "x$1" = "x-x" ] ; then
	# echo "boom \"$2\" \"$3\" \"$4\" \"$5\""
	boom $2 $3 $4 $5
	exit
fi

# DO_MAIN="no"

if [ "x$DO_MAIN" = "x" ] ; then

	update_table_caches

	echo "Testing boom.sh"
	hide_cursor

#        local X=$1
#        local Y=$2
#        local MAX_EXPLOSION_DIAMETER=$3
#        local SIZE=$5

	# Center X,Y
	X=10
	Y=10

	# MAXSIZE=9
	# MINBRIGHT="$(eval echo "\$BALL_D$MAXSIZE""_MINBRIGHT")"

	clear

	j=0
	while [ $j -le 13 ] ; do
		COLOR=$((($j % 6) + 1))

		boom $X $Y $j $COLOR
		j=$(($j + 1))
	done

	show_cursor
fi

update_table_cache()
{
	local ORIG="$1"
	local CACHEFILE="$2"

	echo "COPYING $ORIG to $CACHEFILE"
	. "$ORIG"

	MINBRIGHT="$(eval echo "\$$FILE_CLASS""_D$FILE_DIAMETER""_MINBRIGHT")"
	NLINES="$(eval echo "\$$FILE_CLASS""_D$FILE_DIAMETER""_NLINES")"

	local VTS="$ESC[\$VTS_ROW"";\$VTS_COL""H"
	local STARTCOLOR="$SET$FOREGROUND\$COLOR$ATTRIBUTE"
	local ENDCOLOR="$SET$FOREGROUND$DEFAULT$ATTRIBUTE"

	OUTSTRING=""
	SEMI=""
	BRIGHTNESS=10
	while [ $BRIGHTNESS -ge $(($MINBRIGHT - 1)) ] ; do
		LINE=0
		if [ $BRIGHTNESS -eq $(($MINBRIGHT - 1)) ] ; then
			BRIGHTVAL="C"
		else
			BRIGHTVAL="$BRIGHTNESS"
		fi

		OUTSTRING="$OUTSTRING$SEMI $FILE_CLASS""_D$FILE_DIAMETER""_B$BRIGHTVAL""_CACHEDATA='"
		SEMI=";"

		while [ $LINE -le $NLINES ] ; do
			LINEDATA="$(eval echo "\"\$$FILE_CLASS""_D$FILE_DIAMETER""_B$BRIGHTVAL""_LINE$LINE\"")"
			if [ $LINE -eq 0 ] ; then
				DROP=""
			else
				DROP="$ESC[$LINE""B"
			fi

			# echo "LINEDATA: $LINEDATA"
			# QUOTELINEDATA="$(echo "$LINEDATA" | sed -e 's/\\/\\\\\\\\/g' -e 's/"/\\\\"/g' -e 's/\`/\\\\\`/g' -e 's/\$/\\\\\$/g' )"
			QUOTELINEDATA="$(echo "$LINEDATA" | sed -e "s/'/'\"'\"'/g")"
			OUTSTRING="$OUTSTRING$VTS$DROP$STARTCOLOR$QUOTELINEDATA$ENDCOLOR"

			LINE=$(($LINE + 1))
		done
		OUTSTRING="$OUTSTRING'"

		BRIGHTNESS=$(($BRIGHTNESS - 1))
	done
	echo "$OUTSTRING" > $CACHEFILE

}

update_table_caches()
{
	echo "Checking table caches"
	local ORIGFILE
	local FIRST=1

	mkdir -p "$GAMEDIR/tablecache"

	for ORIGFILE in "$GAMEDIR"/tables/*/table_*.sh ; do
		local REBUILD=0

		local CACHEDIRPATH="$(dirname "$ORIGFILE")"
		local CACHEDIR="$(basename "$CACHEDIRPATH")"
		local CACHEFILE="$GAMEDIR/tablecache/$CACHEDIR/$(basename "$ORIGFILE")"

		if [ ! -f $CACHEFILE ] ; then
			echo "$CACHEFILE not found in cache."

			REBUILD=1
		else 
			ORIGMOD="$(stat -f '%m' -t '%s' $ORIGFILE)"
			CACHEMOD="$(stat -f '%m' -t '%s' $CACHEFILE)"

			if [ $ORIGMOD -gt $CACHEMOD ] ; then
				echo "$CACHEFILE stale in cache."

				REBUILD=1
			fi
		fi

		if [ $REBUILD = 1 ] ; then
			if [ $FIRST = 1 ] ; then
				echo "Updating table caches"
				FIRST=0
			fi

			mkdir -p "$GAMEDIR/tablecache/$CACHEDIR"

			# echo update_table_cache "$ORIGFILE" "$CACHEFILE"
			update_table_cache "$ORIGFILE" "$CACHEFILE"
		fi
	done

	if [ $FIRST = 1 ] ; then
		echo "Table caches up-to-date"
	fi

	for i in "$GAMEDIR"/tablecache/*/* ; do
		. "$i"
	done

	return
}

