
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>

main(int argc, char *argv[])
{
	struct timeval tm;

	gettimeofday(&tm, NULL);


	printf("%lld.%06d\n", (long long)tm.tv_sec, tm.tv_usec);
}

