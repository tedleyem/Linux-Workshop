#!/bin/sh

function drawball()
{
	local X=$1;
	local Y=$2;
	local RADIUS=$3;

	case DIAMETER in
		11)
			HCENTER=6
			VCENTER=4
			MAX=7
			LINE1=" ,\,'|',/, "
			LINE2="','\'|'/','"
			LINE3="-,',\|/,',-"
			LINE4="--+==X==+--"
			LINE5="-','/|\','-"
			LINE6=",',/,|,\,',"
			LINE7=" '/',|,'\' "
			;;
		10) # Really 9
			HCENTER=5
			VCENTER=4
			MAX=7
			LINE1=" ,,.|., ."
			LINE2="\X'\|/'X/"
			LINE3=".X.X|X'X."
			LINE4="+=Z=+=Z=+"
			LINE5="`X`X|X'X`"
			LINE6="/.X.|.X.\"
			LINE7=" '`'|'`' "
			;;
		9)
			HCENTER=5
			VCENTER=4
			MAX=7
			LINE1="  ,...,  "
			LINE2=".`X`|`X`."
			LINE3=".`.X|X.`."
			LINE4="-=+-*-+=-"
			LINE5="`.`X|X`.`"
			LINE6="`.X.|.X.`"
			LINE7="  `'''`  "
			;;
		8) # Really 7
			HCENTER=4
			VCENTER=3
			MAX=5
			LINE1="\X|I|X/"
			LINE2="V\V|Z/7"
			LINE3="+Z=X=Z+"
			LINE4="7/Z|V\V"
			LINE5="\X|I|X\"
			;;
		7)
			HCENTER=4
			VCENTER=3
			MAX=5
			LINE1=" \,|,/ "
			LINE2="',\|/,'"
			LINE3="-=+X+=-"
			LINE4=",'/|\',"
			LINE5=" /'|'\ "
			;;
		6) # Really 5
			HCENTER=3
			VCENTER=3
			MAX=5
			LINE1=" .,. "
			LINE2=",\|/,"
			LINE3="-=+=-"
			LINE4="'/|\'"
			LINE5=" '`' "
			;;
		5)
			HCENTER=3
			VCENTER=3
			MAX=5
			LINE1="  ,  "
			LINE2=".XIX."
			LINE3="=-*-="
			LINE4="`XIX`"
			LINE5="  '  "
			;;
		4) # Really 3
			HCENTER=3
			VCENTER=2
			MAX=3
			LINE1=",|,"
			LINE2="-X-"
			LINE3="'|'"
			;;
		3)
			HCENTER=3
			VCENTER=2
			MAX=3
			LINE1=" . "
			LINE2="~X~"
			LINE3=" ' "
			;;
		2)
			HCENTER=1
			VCENTER=1
			MAX=1
			LINE1="O"
			;;
		1)
			HCENTER=1
			VCENTER=1
			MAX=1
			LINE1="o"
			;;
			;;
		0)
			HCENTER=3
			VCENTER=2
			MAX=1
			LINE1="."
			;;

esac;

	HPOS=$(($X - HCENTER + 1))
	VPOS=$(($Y - VCENTER + 1))



}


function boom1()
{
	local X=$1
	local Y=$2
	local EXPLOSION_RADIUS=$3
	local PART_RADIUS=$4





}












if [ "x$DO_MAIN" = "x" ] ; then
	echo "Testing boom.sh"

fi

