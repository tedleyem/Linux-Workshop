#!/bin/sh

FILE_CLASS="CIRCLES"
FILE_DIAMETER="12"

# Diameter 12
CIRCLES_D12_HCENTER=10
CIRCLES_D12_VCENTER=6
CIRCLES_D12_NLINES=11
CIRCLES_D12_MINBRIGHT=10

# BRIGHTNESS 10
 CIRCLES_D12_B10_LINE1="                   "
 CIRCLES_D12_B10_LINE2="                   "
 CIRCLES_D12_B10_LINE3="  .      .     .   "
 CIRCLES_D12_B10_LINE4="    .  ' .   ' . . "
 CIRCLES_D12_B10_LINE5="' '                "
 CIRCLES_D12_B10_LINE6=" '.   '   .  '    '"
 CIRCLES_D12_B10_LINE7="   .           .   "
 CIRCLES_D12_B10_LINE8="         '        ."
 CIRCLES_D12_B10_LINE9=" '     '    '      "
CIRCLES_D12_B10_LINE10="   '           '   "
CIRCLES_D12_B10_LINE11="'         '       '"


