#!/bin/sh

FILE_CLASS="CIRCLES"
FILE_DIAMETER="9"

# Diameter 9
CIRCLES_D9_HCENTER=10
CIRCLES_D9_VCENTER=6
CIRCLES_D9_NLINES=11
CIRCLES_D9_MINBRIGHT=10

# BRIGHTNESS 10
 CIRCLES_D9_B10_LINE1="                   "
 CIRCLES_D9_B10_LINE2="     ' O ' O '     "
 CIRCLES_D9_B10_LINE3=" ' O ' .   . ' O ' "
 CIRCLES_D9_B10_LINE4="   . .       . .   "
 CIRCLES_D9_B10_LINE5="     ' O ' O '     "
 CIRCLES_D9_B10_LINE6="      ' ' ' '      "
 CIRCLES_D9_B10_LINE7="  ' ' '8 ' 8' ' '  "
 CIRCLES_D9_B10_LINE8="     .   .   .     "
 CIRCLES_D9_B10_LINE9=" ' O '. . . .' O ' "
CIRCLES_D9_B10_LINE10="  . .  O   O  . .  "
CIRCLES_D9_B10_LINE11="      .  .  .      "

