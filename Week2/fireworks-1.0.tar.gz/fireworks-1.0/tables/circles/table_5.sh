#!/bin/sh

FILE_CLASS="CIRCLES"
FILE_DIAMETER="5"

# Diameter 5
CIRCLES_D5_HCENTER=10
CIRCLES_D5_VCENTER=6
CIRCLES_D5_NLINES=11
CIRCLES_D5_MINBRIGHT=10

# BRIGHTNESS 10
 CIRCLES_D5_B10_LINE1="                   "
 CIRCLES_D5_B10_LINE2="                   "
 CIRCLES_D5_B10_LINE3="     . .   . .     "
 CIRCLES_D5_B10_LINE4="      O     O      "
 CIRCLES_D5_B10_LINE5="     ' '   ' '     "
 CIRCLES_D5_B10_LINE6="                   "
 CIRCLES_D5_B10_LINE7="     . .   . .     "
 CIRCLES_D5_B10_LINE8="      O     O      "
 CIRCLES_D5_B10_LINE9="     ' '   ' '     "
CIRCLES_D5_B10_LINE10="                   "
CIRCLES_D5_B10_LINE11="                   "

