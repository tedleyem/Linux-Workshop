#!/bin/sh

FILE_CLASS="CIRCLES"
FILE_DIAMETER="13"

# Diameter 13
CIRCLES_D13_HCENTER=10
CIRCLES_D13_VCENTER=6
CIRCLES_D13_NLINES=11
CIRCLES_D13_MINBRIGHT=10

# BRIGHTNESS 10
 CIRCLES_D13_B10_LINE1="                   "
 CIRCLES_D13_B10_LINE2="                   "
 CIRCLES_D13_B10_LINE3="                   "
 CIRCLES_D13_B10_LINE4=" '     .'     . '  "
 CIRCLES_D13_B10_LINE5=".  '     '        '"
 CIRCLES_D13_B10_LINE6=" .    .       .    "
 CIRCLES_D13_B10_LINE7="  '                "
 CIRCLES_D13_B10_LINE8="  '       .     '  "
 CIRCLES_D13_B10_LINE9="       .          '"
CIRCLES_D13_B10_LINE10="   .            .  "
CIRCLES_D13_B10_LINE11="                   "


