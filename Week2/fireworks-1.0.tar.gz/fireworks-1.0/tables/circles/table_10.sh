#!/bin/sh

FILE_CLASS="CIRCLES"
FILE_DIAMETER="10"

# Diameter 10
CIRCLES_D10_HCENTER=10
CIRCLES_D10_VCENTER=6
CIRCLES_D10_NLINES=11
CIRCLES_D10_MINBRIGHT=10

# BRIGHTNESS 10
 CIRCLES_D10_B10_LINE1="                   "
 CIRCLES_D10_B10_LINE2="    .  o . o .     "
 CIRCLES_D10_B10_LINE3=" . o . '    '  o . "
 CIRCLES_D10_B10_LINE4="  '  .  ' '        "
 CIRCLES_D10_B10_LINE5="  ' .' o . o  ' '  "
 CIRCLES_D10_B10_LINE6="     .  . . '.     "
 CIRCLES_D10_B10_LINE7=" . .   o ' o  .  . "
 CIRCLES_D10_B10_LINE8="        ' '        "
 CIRCLES_D10_B10_LINE9=" , o'.   '   ''o , "
CIRCLES_D10_B10_LINE10="  '  ' o'  8 '  '  "
CIRCLES_D10_B10_LINE11="   '   '   '     ' "


