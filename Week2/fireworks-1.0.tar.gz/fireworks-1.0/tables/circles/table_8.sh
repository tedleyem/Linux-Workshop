#!/bin/sh

FILE_CLASS="CIRCLES"
FILE_DIAMETER="8"

# Diameter 8
CIRCLES_D8_HCENTER=10
CIRCLES_D8_VCENTER=6
CIRCLES_D8_NLINES=11
CIRCLES_D8_MINBRIGHT=10

# BRIGHTNESS 10
 CIRCLES_D8_B10_LINE1="      . . . .      "
 CIRCLES_D8_B10_LINE2="  . .  o   o  . .  "
 CIRCLES_D8_B10_LINE3="   o  ' ' ' '  o   "
 CIRCLES_D8_B10_LINE4="  ' ''. . . .'' '  "
 CIRCLES_D8_B10_LINE5="       o   o       "
 CIRCLES_D8_B10_LINE6="   :  : : : :  :   "
 CIRCLES_D8_B10_LINE7="       o   o       "
 CIRCLES_D8_B10_LINE8="  . .,' ' ' ',. .  "
 CIRCLES_D8_B10_LINE9="   o  . . . .  o   "
CIRCLES_D8_B10_LINE10="  ' '  o   o  ' '  "
CIRCLES_D8_B10_LINE11="      ' ' ' '      "

