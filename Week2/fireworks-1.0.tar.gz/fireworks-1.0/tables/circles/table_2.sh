#!/bin/sh

FILE_CLASS="CIRCLES"
FILE_DIAMETER="2"

# Diameter 2
CIRCLES_D2_HCENTER=10
CIRCLES_D2_VCENTER=6
CIRCLES_D2_NLINES=11
CIRCLES_D2_MINBRIGHT=10

# BRIGHTNESS 10
 CIRCLES_D2_B10_LINE1="                   "
 CIRCLES_D2_B10_LINE2="                   "
 CIRCLES_D2_B10_LINE3="                   "
 CIRCLES_D2_B10_LINE4="                   "
 CIRCLES_D2_B10_LINE5="       '   '       "
 CIRCLES_D2_B10_LINE6="         o         "
 CIRCLES_D2_B10_LINE7="       ,   ,       "
 CIRCLES_D2_B10_LINE8="                   "
 CIRCLES_D2_B10_LINE9="                   "
CIRCLES_D2_B10_LINE10="                   "
CIRCLES_D2_B10_LINE11="                   "

