#!/bin/sh

FILE_CLASS="STREAMER"
FILE_DIAMETER="11"

# Diameter 11
STREAMER_D11_HCENTER=8
STREAMER_D11_VCENTER=5
STREAMER_D11_NLINES=9
STREAMER_D11_MINBRIGHT=0

# BRIGHTNESS 10
STREAMER_D11_B10_LINE1="   ,''   '',   "
STREAMER_D11_B10_LINE2="  ,  '      ,  "
STREAMER_D11_B10_LINE3="  ' '     ' '  "
STREAMER_D11_B10_LINE4="   ,   '   ,   "
STREAMER_D11_B10_LINE5="  ,         ,  "
STREAMER_D11_B10_LINE6="  '  ,   ,  '  "
STREAMER_D11_B10_LINE7="     '   '     "
STREAMER_D11_B10_LINE8="               "
STREAMER_D11_B10_LINE9="               "


# BRIGHTNESS 9
# STREAMER_D11_B9_LINE1="    ,     ,    "
# STREAMER_D11_B9_LINE2="   ' /   \ '   "
# STREAMER_D11_B9_LINE3="  i,       ,i  "
# STREAMER_D11_B9_LINE4="       ,       "
# STREAMER_D11_B9_LINE5="  '         '  "
# STREAMER_D11_B9_LINE6="  \         /  "
# STREAMER_D11_B9_LINE7="     i   i     "
# STREAMER_D11_B9_LINE8="               "
# STREAMER_D11_B9_LINE9="               "
STREAMER_D11_B9_LINE1="    ,     ,    "
STREAMER_D11_B9_LINE2="   ' /   \\ '   "
STREAMER_D11_B9_LINE3="  i,       ,i  "
STREAMER_D11_B9_LINE4="       ,       "
STREAMER_D11_B9_LINE5="  '         '  "
STREAMER_D11_B9_LINE6="  \\         /  "
STREAMER_D11_B9_LINE7="     i   i     "
STREAMER_D11_B9_LINE8="               "
STREAMER_D11_B9_LINE9="               "


# BRIGHTNESS 8
# STREAMER_D11_B8_LINE1="               "
# STREAMER_D11_B8_LINE2="  , '.   .' ,  "
# STREAMER_D11_B8_LINE3="  , '     ` ,  "
# STREAMER_D11_B8_LINE4=" ' `       ' ` "
# STREAMER_D11_B8_LINE5="  ,   '     ,  "
# STREAMER_D11_B8_LINE6="  ,         ,  "
# STREAMER_D11_B8_LINE7="  ' ,     , '  "
# STREAMER_D11_B8_LINE8="    '     '    "
# STREAMER_D11_B8_LINE9="               "
STREAMER_D11_B8_LINE1="               "
STREAMER_D11_B8_LINE2="  , '.   .' ,  "
STREAMER_D11_B8_LINE3="  , '     \` ,  "
STREAMER_D11_B8_LINE4=" ' \`       ' \` "
STREAMER_D11_B8_LINE5="  ,   '     ,  "
STREAMER_D11_B8_LINE6="  ,         ,  "
STREAMER_D11_B8_LINE7="  ' ,     , '  "
STREAMER_D11_B8_LINE8="    '     '    "
STREAMER_D11_B8_LINE9="               "


# BRIGHTNESS 7
STREAMER_D11_B7_LINE1="               "
STREAMER_D11_B7_LINE2="   .'     '.   "
STREAMER_D11_B7_LINE3=" '  . ' ' .  ' "
STREAMER_D11_B7_LINE4=" ,'.       ,'. "
STREAMER_D11_B7_LINE5="               "
STREAMER_D11_B7_LINE6="  '   '     '  "
STREAMER_D11_B7_LINE7="  |         |  "
STREAMER_D11_B7_LINE8="    |     |    "
STREAMER_D11_B7_LINE9="               "


# BRIGHTNESS 6
STREAMER_D11_B6_LINE1="               "
STREAMER_D11_B6_LINE2="    .     .    "
STREAMER_D11_B6_LINE3=" .'    x    '. "
STREAMER_D11_B6_LINE4=" . '       ' . "
STREAMER_D11_B6_LINE5=" ' '       '  '"
STREAMER_D11_B6_LINE6="  ,   .     ,  "
STREAMER_D11_B6_LINE7="  ,         ,  "
STREAMER_D11_B6_LINE8="  ' .     . '  "
STREAMER_D11_B6_LINE9="          '    "


# BRIGHTNESS 5
STREAMER_D11_B5_LINE1="               "
STREAMER_D11_B5_LINE2="               "
STREAMER_D11_B5_LINE3="  .'       '.  "
STREAMER_D11_B5_LINE4="'  .  ' '  .  '"
STREAMER_D11_B5_LINE5=" . .       . '."
STREAMER_D11_B5_LINE6="   '        , '"
STREAMER_D11_B5_LINE7="  '   '        "
STREAMER_D11_B5_LINE8=" .'         '. "
STREAMER_D11_B5_LINE9="   '      '    "

# BRIGHTNESS 4
STREAMER_D11_B4_LINE1="               "
STREAMER_D11_B4_LINE2="               "
STREAMER_D11_B4_LINE3="   .       .   "
STREAMER_D11_B4_LINE4=". '   . .   ' ."
STREAMER_D11_B4_LINE5="  '.       ' . "
STREAMER_D11_B4_LINE6=" ' i       '  ."
STREAMER_D11_B4_LINE7="  .          ' "
STREAMER_D11_B4_LINE8="  .   '     .  "
STREAMER_D11_B4_LINE9="'  .          '"

# BRIGHTNESS 3
STREAMER_D11_B3_LINE1="               "
STREAMER_D11_B3_LINE2="               "
STREAMER_D11_B3_LINE3="               "
STREAMER_D11_B3_LINE4="  .'       '.  "
STREAMER_D11_B3_LINE5="'.     ' ' .  '"
STREAMER_D11_B3_LINE6=" . '       .  '"
STREAMER_D11_B3_LINE7="             . "
STREAMER_D11_B3_LINE8="  '    .       "
STREAMER_D11_B3_LINE9="  '          ' "


# BRIGHTNESS 2
STREAMER_D11_B2_LINE1="               "
STREAMER_D11_B2_LINE2="               "
STREAMER_D11_B2_LINE3="               "
STREAMER_D11_B2_LINE4="   .       .   "
STREAMER_D11_B2_LINE5=". '      .  ' '"
STREAMER_D11_B2_LINE6=" ' .  '    '  '"
STREAMER_D11_B2_LINE7=" '          '  "
STREAMER_D11_B2_LINE8="  .          ' "
STREAMER_D11_B2_LINE9="             . "

# BRIGHTNESS 1
STREAMER_D11_B1_LINE1="               "
STREAMER_D11_B1_LINE2="               "
STREAMER_D11_B1_LINE3="               "
STREAMER_D11_B1_LINE4="               "
STREAMER_D11_B1_LINE5="   '       '  ."
STREAMER_D11_B1_LINE6="'     '  ' .   "
STREAMER_D11_B1_LINE7=" .            '"
STREAMER_D11_B1_LINE8="             . "
STREAMER_D11_B1_LINE9="               "

# BRIGHTNESS 0
# STREAMER_D11_B0_LINE1="               "
# STREAMER_D11_B0_LINE2="               "
# STREAMER_D11_B0_LINE3="               "
# STREAMER_D11_B0_LINE4="               "
# STREAMER_D11_B0_LINE5="               "
# STREAMER_D11_B0_LINE6="   '       `   "
# STREAMER_D11_B0_LINE7="      .     '  "
# STREAMER_D11_B0_LINE8=" '             "
# STREAMER_D11_B0_LINE9="             ' "
STREAMER_D11_B0_LINE1="               "
STREAMER_D11_B0_LINE2="               "
STREAMER_D11_B0_LINE3="               "
STREAMER_D11_B0_LINE4="               "
STREAMER_D11_B0_LINE5="               "
STREAMER_D11_B0_LINE6="   '       \`   "
STREAMER_D11_B0_LINE7="      .     '  "
STREAMER_D11_B0_LINE8=" '             "
STREAMER_D11_B0_LINE9="             ' "

STREAMER_D11_BC_LINE1="               "
STREAMER_D11_BC_LINE2="               "
STREAMER_D11_BC_LINE3="               "
STREAMER_D11_BC_LINE4="               "
STREAMER_D11_BC_LINE5="               "
STREAMER_D11_BC_LINE6="               "
STREAMER_D11_BC_LINE7="               "
STREAMER_D11_BC_LINE8="               "
STREAMER_D11_BC_LINE9="               "

