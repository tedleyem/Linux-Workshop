#!/bin/sh

FILE_CLASS="STREAMER"
FILE_DIAMETER="8"

# Diameter 8
STREAMER_D8_HCENTER=8
STREAMER_D8_VCENTER=5
STREAMER_D8_NLINES=9
STREAMER_D8_MINBRIGHT=10

# BRIGHTNESS 10
# STREAMER_D8_B10_LINE1="   /',   ,'\   "
# STREAMER_D8_B10_LINE2="      ,i,      "
# STREAMER_D8_B10_LINE3="    ,  *  ,    "
# STREAMER_D8_B10_LINE4="  .'       '.  "
# STREAMER_D8_B10_LINE5="     i   i     "
# STREAMER_D8_B10_LINE6="               "
# STREAMER_D8_B10_LINE7="               "
# STREAMER_D8_B10_LINE8="               "
# STREAMER_D8_B10_LINE9="               "

STREAMER_D8_B10_LINE1="   /',   ,'\\   "
STREAMER_D8_B10_LINE2="      ,i,      "
STREAMER_D8_B10_LINE3="    ,  *  ,    "
STREAMER_D8_B10_LINE4="  .'       '.  "
STREAMER_D8_B10_LINE5="     i   i     "
STREAMER_D8_B10_LINE6="               "
STREAMER_D8_B10_LINE7="               "
STREAMER_D8_B10_LINE8="               "
STREAMER_D8_B10_LINE9="               "

