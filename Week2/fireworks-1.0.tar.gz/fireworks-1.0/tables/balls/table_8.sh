#!/bin/sh

FILE_CLASS="BALL"
FILE_DIAMETER="8"

# Diameter 8 (really 7)
BALL_D8_HCENTER=4
BALL_D8_VCENTER=3
BALL_D8_NLINES=5
BALL_D8_MINBRIGHT=0

# BRIGHTNESS: 10
# BALL_D8_B10_LINE1="\X|I|X/"
# BALL_D8_B10_LINE2="V\V|Z/7"
# BALL_D8_B10_LINE3="+Z=X=Z+"
# BALL_D8_B10_LINE4="7/Z|V\V"
# BALL_D8_B10_LINE5="/X|I|X\"

BALL_D8_B10_LINE1="\\X|I|X/"
BALL_D8_B10_LINE2="V\\V|Z/7"
BALL_D8_B10_LINE3="+Z=X=Z+"
BALL_D8_B10_LINE4="7/Z|V\\V"
BALL_D8_B10_LINE5="/X|I|X\\"

# BRIGHTNESS: 9
# BALL_D8_B9_LINE1=", .,. ,"
# BALL_D8_B9_LINE2=" \'|'/ "
# BALL_D8_B9_LINE3="-=-*-=-"
# BALL_D8_B9_LINE4=" /,|,\ "
# BALL_D8_B9_LINE5="' `'` '"
BALL_D8_B9_LINE1=", .,. ,"
BALL_D8_B9_LINE2=" \\'|'/ "
BALL_D8_B9_LINE3="-=-*-=-"
BALL_D8_B9_LINE4=" /,|,\\ "
BALL_D8_B9_LINE5="' \`'\` '"

# BRIGHTNESS: 8
# BALL_D8_B8_LINE1="' ' ' '"
# BALL_D8_B8_LINE2=" ' , ' "
# BALL_D8_B8_LINE3=" - O - "
# BALL_D8_B8_LINE4=" , ' , "
# BALL_D8_B8_LINE5=", , , ,"
BALL_D8_B8_LINE1="' ' ' '"
BALL_D8_B8_LINE2=" ' , ' "
BALL_D8_B8_LINE3=" - O - "
BALL_D8_B8_LINE4=" , ' , "
BALL_D8_B8_LINE5=", , , ,"

# BRIGHTNESS: 7
# BALL_D8_B7_LINE1=" , , , "
# BALL_D8_B7_LINE2="'` . `'"
# BALL_D8_B7_LINE3="- - - -"
# BALL_D8_B7_LINE4="., '  ."
# BALL_D8_B7_LINE5=" ' ' ' "
BALL_D8_B7_LINE1=" , , , "
BALL_D8_B7_LINE2="'\` . \`'"
BALL_D8_B7_LINE3="- - - -"
BALL_D8_B7_LINE4="., '  ."
BALL_D8_B7_LINE5=" ' ' ' "

# BRIGHTNESS: 6
# BALL_D8_B6_LINE1=".  .  ."
# BALL_D8_B6_LINE2="   '   "
# BALL_D8_B6_LINE3=" -   - "
# BALL_D8_B6_LINE4="   ,   "
# BALL_D8_B6_LINE5="'  `  '"
BALL_D8_B6_LINE1=".  .  ."
BALL_D8_B6_LINE2="   '   "
BALL_D8_B6_LINE3=" -   - "
BALL_D8_B6_LINE4="   ,   "
BALL_D8_B6_LINE5="'  \`  '"

# BRIGHTNESS: 5
# BALL_D8_B5_LINE1="       "
# BALL_D8_B5_LINE2="  ' `  "
# BALL_D8_B5_LINE3="- . ' -"
# BALL_D8_B5_LINE4="  , .  "
# BALL_D8_B5_LINE5="       "
BALL_D8_B5_LINE1="       "
BALL_D8_B5_LINE2="  ' \`  "
BALL_D8_B5_LINE3="- . ' -"
BALL_D8_B5_LINE4="  , .  "
BALL_D8_B5_LINE5="       "

# BRIGHTNESS: 4
# BALL_D8_B4_LINE1="  , ,  "
# BALL_D8_B4_LINE2=" ,   , "
# BALL_D8_B4_LINE3="   .   "
# BALL_D8_B4_LINE4=" '   ' "
# BALL_D8_B4_LINE5="  ' '  "
BALL_D8_B4_LINE1="  , ,  "
BALL_D8_B4_LINE2=" ,   , "
BALL_D8_B4_LINE3="   .   "
BALL_D8_B4_LINE4=" '   ' "
BALL_D8_B4_LINE5="  ' '  "

# BRIGHTNESS: 3
# BALL_D8_B3_LINE1=" . . . "
# BALL_D8_B3_LINE2="'  .  '"
# BALL_D8_B3_LINE3="  . .  "
# BALL_D8_B3_LINE4="   '   "
# BALL_D8_B3_LINE5=" ' ' ' "
BALL_D8_B3_LINE1=" . . . "
BALL_D8_B3_LINE2="'  .  '"
BALL_D8_B3_LINE3="  . .  "
BALL_D8_B3_LINE4="   '   "
BALL_D8_B3_LINE5=" ' ' ' "

# BRIGHTNESS: 2
# BALL_D8_B2_LINE1="  . .  "
# BALL_D8_B2_LINE2=" .   .'"
# BALL_D8_B2_LINE3="       "
# BALL_D8_B2_LINE4=" '   ' "
# BALL_D8_B2_LINE5="  ' '  "
BALL_D8_B2_LINE1="  . .  "
BALL_D8_B2_LINE2=" .   .'"
BALL_D8_B2_LINE3="       "
BALL_D8_B2_LINE4=" '   ' "
BALL_D8_B2_LINE5="  ' '  "

# BRIGHTNESS: 1
# BALL_D8_B1_LINE1="`' ' '`"
# BALL_D8_B1_LINE2="'     '"
# BALL_D8_B1_LINE3="       "
# BALL_D8_B1_LINE4=".     ."
# BALL_D8_B1_LINE5="., , ,."
BALL_D8_B1_LINE1="\`' ' '\`"
BALL_D8_B1_LINE2="'     '"
BALL_D8_B1_LINE3="       "
BALL_D8_B1_LINE4=".     ."
BALL_D8_B1_LINE5="., , ,."

# BRIGHTNESS: 0
# BALL_D8_B0_LINE1="`     `"
# BALL_D8_B0_LINE2="       "
# BALL_D8_B0_LINE3="       "
# BALL_D8_B0_LINE4="       "
# BALL_D8_B0_LINE5=".     ."
BALL_D8_B0_LINE1="\`     \`"
BALL_D8_B0_LINE2="       "
BALL_D8_B0_LINE3="       "
BALL_D8_B0_LINE4="       "
BALL_D8_B0_LINE5=".     ."


BALL_D8_BC_LINE1="       "
BALL_D8_BC_LINE2="       "
BALL_D8_BC_LINE3="       "
BALL_D8_BC_LINE4="       "
BALL_D8_BC_LINE5="       "



