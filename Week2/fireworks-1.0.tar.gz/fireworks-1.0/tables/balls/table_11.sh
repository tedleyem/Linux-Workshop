#!/bin/sh

FILE_CLASS="BALL"
FILE_DIAMETER="11"

# Diameter 11
BALL_D11_HCENTER=6
BALL_D11_VCENTER=4
BALL_D11_NLINES=7
BALL_D11_MINBRIGHT=0

# BRIGHTNESS 10
# BALL_D11_B10_LINE1=" ,\,'|',/, "
# BALL_D11_B10_LINE2="','\'|'/','"
# BALL_D11_B10_LINE3="-,',\|/,',-"
# BALL_D11_B10_LINE4="--+==X==+--"
# BALL_D11_B10_LINE5="-','/|\','-"
# BALL_D11_B10_LINE6=",',/,|,\,',"
# BALL_D11_B10_LINE7=" '/',|,'\' "

BALL_D11_B10_LINE1=" ,\\,'|',/, "
BALL_D11_B10_LINE2="','\\'|'/','"
BALL_D11_B10_LINE3="-,',\\|/,',-"
BALL_D11_B10_LINE4="--+==X==+--"
BALL_D11_B10_LINE5="-','/|\\','-"
BALL_D11_B10_LINE6=",',/,|,\\,',"
BALL_D11_B10_LINE7=" '/',|,'\\' "

# BRIGHTNESS 9
# BALL_D11_B9_LINE1=" , ,'|',', "
# BALL_D11_B9_LINE2="' \''|' '/ "
# BALL_D11_B9_LINE3=" ,','|',', "
# BALL_D11_B9_LINE4="----   ----"
# BALL_D11_B9_LINE5=" ',',|.',' "
# BALL_D11_B9_LINE6=" /, ,|, ,\,"
# BALL_D11_B9_LINE7=" ' ',|,' ' "

BALL_D11_B9_LINE1=" , ,'|',', "
BALL_D11_B9_LINE2="' \\''|' '/ "
BALL_D11_B9_LINE3=" ,','|',', "
BALL_D11_B9_LINE4="----   ----"
BALL_D11_B9_LINE5=" ',',|.',' "
BALL_D11_B9_LINE6=" /, ,|, ,\\,"
BALL_D11_B9_LINE7=" ' ',|,' ' "

# BRIGHTNESS 8
# BALL_D11_B8_LINE1=" , , ' ,', "
# BALL_D11_B8_LINE2="'.` '' '','"
# BALL_D11_B8_LINE3=" .' .''.', "
# BALL_D11_B8_LINE4="- -     - -"
# BALL_D11_B8_LINE5=" '.'',,',' "
# BALL_D11_B8_LINE6=",'.' , , ',"
# BALL_D11_B8_LINE7="  '  '  '  "

BALL_D11_B8_LINE1=" , , ' ,', "
BALL_D11_B8_LINE2="'.\` '' '','"
BALL_D11_B8_LINE3=" .' .''.', "
BALL_D11_B8_LINE4="- -     - -"
BALL_D11_B8_LINE5=" '.'',,',' "
BALL_D11_B8_LINE6=",'.' , , ',"
BALL_D11_B8_LINE7="  '  '  '  "

# BRIGHTNESS 7
# BALL_D11_B7_LINE1="  . / '  . "
# BALL_D11_B7_LINE2="  ' ,|  , '"
# BALL_D11_B7_LINE3=".  .  .  ' "
# BALL_D11_B7_LINE4="'-. '  -'-,"
# BALL_D11_B7_LINE5="' ' ,  . , "
# BALL_D11_B7_LINE6="  .   | .  "
# BALL_D11_B7_LINE7="   .\ ,    "

BALL_D11_B7_LINE1="  . / '  . "
BALL_D11_B7_LINE2="  ' ,|  , '"
BALL_D11_B7_LINE3=".  .  .  ' "
BALL_D11_B7_LINE4="'-. '  -'-,"
BALL_D11_B7_LINE5="' ' ,  . , "
BALL_D11_B7_LINE6="  .   | .  "
BALL_D11_B7_LINE7="   .\\ ,    "

# Brightness 6
# BALL_D11_B6_LINE1=". . \ '  . "
# BALL_D11_B6_LINE2="  ' ,   , '"
# BALL_D11_B6_LINE3=".  .  .  ' "
# BALL_D11_B6_LINE4="' .     ' ,"
# BALL_D11_B6_LINE5="' ' ,  . , "
# BALL_D11_B6_LINE6="  .     .  "
# BALL_D11_B6_LINE7=".  .  ,   '"

BALL_D11_B6_LINE1=". . \\ '  . "
BALL_D11_B6_LINE2="  ' ,   , '"
BALL_D11_B6_LINE3=".  .  .  ' "
BALL_D11_B6_LINE4="' .     ' ,"
BALL_D11_B6_LINE5="' ' ,  . , "
BALL_D11_B6_LINE6="  .     .  "
BALL_D11_B6_LINE7=".  .  ,   '"

# Brightness 6
# BALL_D11_B5_LINE1=" ,   ' ,   "
# BALL_D11_B5_LINE2="' ` '   ' '"
# BALL_D11_B5_LINE3=" .   ' .'  "
# BALL_D11_B5_LINE4="'         ."
# BALL_D11_B5_LINE5="    '  ',  "
# BALL_D11_B5_LINE6=" '     , ' "
# BALL_D11_B5_LINE7="     '     "

BALL_D11_B5_LINE1=" ,   ' ,   "
BALL_D11_B5_LINE2="' \` '   ' '"
BALL_D11_B5_LINE3=" .   ' .'  "
BALL_D11_B5_LINE4="'         ."
BALL_D11_B5_LINE5="    '  ',  "
BALL_D11_B5_LINE6=" '     , ' "
BALL_D11_B5_LINE7="     '     "

# Brightness 4
# BALL_D11_B4_LINE1=" . ,'  .   "
# BALL_D11_B4_LINE2="'         ."
# BALL_D11_B4_LINE3=".    .  .  "
# BALL_D11_B4_LINE4=" ,        ."
# BALL_D11_B4_LINE5="    '    , "
# BALL_D11_B4_LINE6=" .      '  "
# BALL_D11_B4_LINE7="     .     "

BALL_D11_B4_LINE1=" . ,'  .   "
BALL_D11_B4_LINE2="'         ."
BALL_D11_B4_LINE3=".    .  .  "
BALL_D11_B4_LINE4=" ,        ."
BALL_D11_B4_LINE5="    '    , "
BALL_D11_B4_LINE6=" .      '  "
BALL_D11_B4_LINE7="     .     "

# Brightness 3
# BALL_D11_B3_LINE1=".     '   '"
# BALL_D11_B3_LINE2="  '     . '"
# BALL_D11_B3_LINE3="   .  .    "
# BALL_D11_B3_LINE4="          ."
# BALL_D11_B3_LINE5="  `     '  "
# BALL_D11_B3_LINE6="       |   "
# BALL_D11_B3_LINE7=".    .   ' "

BALL_D11_B3_LINE1=".     '   '"
BALL_D11_B3_LINE2="  '     . '"
BALL_D11_B3_LINE3="   .  .    "
BALL_D11_B3_LINE4="          ."
BALL_D11_B3_LINE5="  \`     '  "
BALL_D11_B3_LINE6="       |   "
BALL_D11_B3_LINE7=".    .   ' "

# Brightness 2
# BALL_D11_B2_LINE1=" .    .    "
# BALL_D11_B2_LINE2="'       ' ."
# BALL_D11_B2_LINE3=" .  '  .   "
# BALL_D11_B2_LINE4="'          "
# BALL_D11_B2_LINE5="    '   .  "
# BALL_D11_B2_LINE6=" '         "
# BALL_D11_B2_LINE7=".    .    ."

BALL_D11_B2_LINE1=" .    .    "
BALL_D11_B2_LINE2="'       ' ."
BALL_D11_B2_LINE3=" .  '  .   "
BALL_D11_B2_LINE4="'          "
BALL_D11_B2_LINE5="    '   .  "
BALL_D11_B2_LINE6=" '         "
BALL_D11_B2_LINE7=".    .    ."

# Brightness 1
# BALL_D11_B1_LINE1="'     '   '"
# BALL_D11_B1_LINE2="   .      '"
# BALL_D11_B1_LINE3="       '   "
# BALL_D11_B1_LINE4="   '    '  "
# BALL_D11_B1_LINE5="       .   "
# BALL_D11_B1_LINE6=" '        "
# BALL_D11_B1_LINE7=".   .    ' "

BALL_D11_B1_LINE1="'     '   '"
BALL_D11_B1_LINE2="   .      '"
BALL_D11_B1_LINE3="       '   "
BALL_D11_B1_LINE4="   '    '  "
BALL_D11_B1_LINE5="       .   "
BALL_D11_B1_LINE6=" '        "
BALL_D11_B1_LINE7=".   .    ' "

# Brightness 0 FIX
# BALL_D11_B0_LINE1=" .      .  "
# BALL_D11_B0_LINE2="           "
# BALL_D11_B0_LINE3="         . "
# BALL_D11_B0_LINE4="'    .     "
# BALL_D11_B0_LINE5="          ."
# BALL_D11_B0_LINE6=" '         "
# BALL_D11_B0_LINE7="   '   '   "

BALL_D11_B0_LINE1=" .      .  "
BALL_D11_B0_LINE2="           "
BALL_D11_B0_LINE3="         . "
BALL_D11_B0_LINE4="'    .     "
BALL_D11_B0_LINE5="          ."
BALL_D11_B0_LINE6=" '         "
BALL_D11_B0_LINE7="   '   '   "

BALL_D11_BC_LINE1="           "
BALL_D11_BC_LINE2="           "
BALL_D11_BC_LINE3="           "
BALL_D11_BC_LINE4="           "
BALL_D11_BC_LINE5="           "
BALL_D11_BC_LINE6="           "
BALL_D11_BC_LINE7="           "


