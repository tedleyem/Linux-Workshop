
# Balls
. $GAMEDIR/tables/balls/table_0.sh
. $GAMEDIR/tables/balls/table_1.sh
. $GAMEDIR/tables/balls/table_2.sh
. $GAMEDIR/tables/balls/table_3.sh
. $GAMEDIR/tables/balls/table_4.sh
. $GAMEDIR/tables/balls/table_5.sh
. $GAMEDIR/tables/balls/table_6.sh
. $GAMEDIR/tables/balls/table_7.sh
. $GAMEDIR/tables/balls/table_8.sh
. $GAMEDIR/tables/balls/table_9.sh
. $GAMEDIR/tables/balls/table_10.sh
. $GAMEDIR/tables/balls/table_11.sh

# Streamers
. $GAMEDIR/tables/streamers/table_0.sh
. $GAMEDIR/tables/streamers/table_1.sh
. $GAMEDIR/tables/streamers/table_2.sh
. $GAMEDIR/tables/streamers/table_3.sh
. $GAMEDIR/tables/streamers/table_4.sh
. $GAMEDIR/tables/streamers/table_5.sh
. $GAMEDIR/tables/streamers/table_6.sh
. $GAMEDIR/tables/streamers/table_7.sh
. $GAMEDIR/tables/streamers/table_8.sh
. $GAMEDIR/tables/streamers/table_9.sh
. $GAMEDIR/tables/streamers/table_10.sh
. $GAMEDIR/tables/streamers/table_11.sh

# Circles
. $GAMEDIR/tables/circles/table_0.sh
. $GAMEDIR/tables/circles/table_1.sh
. $GAMEDIR/tables/circles/table_2.sh
. $GAMEDIR/tables/circles/table_3.sh
. $GAMEDIR/tables/circles/table_4.sh
. $GAMEDIR/tables/circles/table_5.sh
. $GAMEDIR/tables/circles/table_6.sh
. $GAMEDIR/tables/circles/table_7.sh
. $GAMEDIR/tables/circles/table_8.sh
. $GAMEDIR/tables/circles/table_9.sh
. $GAMEDIR/tables/circles/table_10.sh
. $GAMEDIR/tables/circles/table_11.sh
. $GAMEDIR/tables/circles/table_12.sh
. $GAMEDIR/tables/circles/table_13.sh
. $GAMEDIR/tables/circles/table_14.sh
. $GAMEDIR/tables/circles/table_15.sh
. $GAMEDIR/tables/circles/table_16.sh

